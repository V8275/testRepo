﻿namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private DataGridView dgvData;
        private ComboBox cmbTable;
        private Button btnSave;
        private Button btnDelete;
        private Panel topPanel;
        private Panel bottomPanel;
        private Label lblTable;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgvData = new DataGridView();
            cmbTable = new ComboBox();
            btnSave = new Button();
            btnDelete = new Button();
            topPanel = new Panel();
            bottomPanel = new Panel();
            lblTable = new Label();

            ((System.ComponentModel.ISupportInitialize)dgvData).BeginInit();

            SuspendLayout();

            //
            // topPanel
            //
            topPanel.Dock = DockStyle.Top;
            topPanel.Height = 50;
            topPanel.Padding = new Padding(10);

            //
            // lblTable
            //
            lblTable.AutoSize = true;
            lblTable.Text = "Таблица:";
            lblTable.Location = new Point(10, 15);

            //
            // cmbTable
            //
            cmbTable.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTable.Location = new Point(80, 12);
            cmbTable.Size = new Size(250, 30);
            cmbTable.Font = new Font("Segoe UI", 10F);

            //
            // dgvData
            //
            dgvData.Dock = DockStyle.Fill;
            dgvData.AllowUserToAddRows = true;
            dgvData.AllowUserToDeleteRows = true;
            dgvData.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvData.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvData.MultiSelect = false;

            //
            // bottomPanel
            //
            bottomPanel.Dock = DockStyle.Bottom;
            bottomPanel.Height = 60;
            bottomPanel.Padding = new Padding(10);

            //
            // btnSave
            //
            btnSave.Text = "Сохранить";
            btnSave.Size = new Size(120, 35);
            btnSave.Location = new Point(10, 10);

            btnSave.BackColor = Color.LightGreen;
            btnSave.FlatStyle = FlatStyle.Flat;

            btnSave.Click += btnSave_Click;

            //
            // btnDelete
            //
            btnDelete.Text = "Удалить";
            btnDelete.Size = new Size(120, 35);
            btnDelete.Location = new Point(140, 10);

            btnDelete.BackColor = Color.LightCoral;
            btnDelete.FlatStyle = FlatStyle.Flat;

            btnDelete.Click += btnDelete_Click;

            //
            // добавление контролов
            //
            topPanel.Controls.Add(lblTable);
            topPanel.Controls.Add(cmbTable);

            bottomPanel.Controls.Add(btnSave);
            bottomPanel.Controls.Add(btnDelete);

            Controls.Add(dgvData);
            Controls.Add(bottomPanel);
            Controls.Add(topPanel);

            //
            // Form1
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;

            ClientSize = new Size(1200, 700);

            MinimumSize = new Size(900, 500);

            StartPosition = FormStartPosition.CenterScreen;

            Text = "Библиотека";

            ((System.ComponentModel.ISupportInitialize)dgvData).EndInit();

            ResumeLayout(false);
        }
    }
}