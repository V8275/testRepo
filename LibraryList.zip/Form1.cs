using Microsoft.EntityFrameworkCore;
using WindowsFormsApp1.Context;
using WindowsFormsApp1.Models;

namespace WinFormsApp1;

public partial class Form1 : Form
{
    private readonly ApplicationDbContext _db;

    private BindingSource _source = new();

    public Form1()
    {
        InitializeComponent();

        _db = new ApplicationDbContext();

        _db.Database.EnsureCreated();

        cmbTable.Items.Add("�����");
        cmbTable.Items.Add("��������");
        cmbTable.Items.Add("������");

        cmbTable.SelectedIndex = 0;

        dgvData.AutoGenerateColumns = true;
        dgvData.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;

        dgvData.AllowUserToAddRows = true;
        dgvData.AllowUserToDeleteRows = true;

        cmbTable.SelectedIndexChanged += CmbTable_SelectedIndexChanged;

        LoadCurrentTable();
    }

    private void CmbTable_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadCurrentTable();
    }

    private void LoadCurrentTable()
    {
        switch (cmbTable.Text)
        {
            case "�����":
                _db.Books.Load();

                _source.DataSource =
                    _db.Books.Local.ToBindingList();

                dgvData.DataSource = _source;

                HideBookColumns();

                break;

            case "��������":
                _db.Readers.Load();

                _source.DataSource =
                    _db.Readers.Local.ToBindingList();

                dgvData.DataSource = _source;

                HideReaderColumns();

                break;

            case "������":
                _db.BookLoans
                    .Include(x => x.Book)
                    .Include(x => x.Reader)
                    .Include(x => x.Admin)
                    .Load();

                _source.DataSource =
                    _db.BookLoans.Local.ToBindingList();

                dgvData.DataSource = _source;

                HideLoanColumns();

                break;
        }
    }

    private void HideBookColumns()
    {
        dgvData.Columns["BookLoans"].Visible = false;

        dgvData.Columns["Title"].HeaderText = "��������";
        dgvData.Columns["Author"].HeaderText = "�����";
        dgvData.Columns["PublicationYear"].HeaderText = "���";
        dgvData.Columns["Genre"].HeaderText = "����";
        dgvData.Columns["Quantity"].HeaderText = "����������";
        dgvData.Columns["AvailableQuantity"].HeaderText = "��������";
    }

    private void HideReaderColumns()
    {
        dgvData.Columns["BookLoans"].Visible = false;

        dgvData.Columns["FirstName"].HeaderText = "���";
        dgvData.Columns["LastName"].HeaderText = "�������";
        dgvData.Columns["Phone"].HeaderText = "�������";
        dgvData.Columns["Address"].HeaderText = "�����";
    }

    private void HideLoanColumns()
    {
        dgvData.Columns["Book"].Visible = false;
        dgvData.Columns["Reader"].Visible = false;
        dgvData.Columns["Admin"].Visible = false;

        dgvData.Columns["BookId"].HeaderText = "�����";
        dgvData.Columns["ReaderId"].HeaderText = "��������";
        dgvData.Columns["AdminId"].HeaderText = "�������������";
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            dgvData.EndEdit();

            foreach (var entry in _db.ChangeTracker.Entries())
            {
                if (entry.State == EntityState.Added)
                {
                    switch (entry.Entity)
                    {
                        case Book book:
                            book.AddedDate = DateTime.Now;
                            break;

                        case Reader reader:
                            reader.RegistrationDate = DateTime.Now;
                            reader.IsActive = true;
                            break;

                        case BookLoan loan:
                            loan.LoanDate = DateTime.Now;

                            if (loan.Status == null)
                                loan.Status = "Active";

                            break;
                    }
                }
            }

            _db.SaveChanges();

            MessageBox.Show(
                "��������� ���������",
                "�����",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (dgvData.CurrentRow == null)
            return;

        var item = dgvData.CurrentRow.DataBoundItem;

        if (item == null)
            return;

        var result = MessageBox.Show(
            "������� ������?",
            "�������������",
            MessageBoxButtons.YesNo);

        if (result != DialogResult.Yes)
            return;

        _source.Remove(item);

        _db.SaveChanges();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _db.Dispose();

        base.OnFormClosing(e);
    }
}