﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WindowsFormsApp1.Models
{
    public class Book
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(100)]
        public string Author { get; set; }

        [MaxLength(50)]
        public string ISBN { get; set; }

        public int PublicationYear { get; set; }

        [MaxLength(50)]
        public string Genre { get; set; }

        public int Quantity { get; set; }

        public int AvailableQuantity { get; set; }

        public DateTime AddedDate { get; set; }

        public virtual ICollection<BookLoan> BookLoans { get; set; }
    }

    public class Admin
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Username { get; set; }

        [Required]
        [MaxLength(255)]
        public string PasswordHash { get; set; }

        [Required]
        [MaxLength(100)]
        public string FullName { get; set; }

        [MaxLength(100)]
        public string Email { get; set; }

        public DateTime CreatedDate { get; set; }

        public bool IsActive { get; set; }
    }

    public class Reader
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        [MaxLength(100)]
        public string Email { get; set; }

        [MaxLength(20)]
        public string Phone { get; set; }

        [MaxLength(200)]
        public string Address { get; set; }

        public DateTime RegistrationDate { get; set; }

        public bool IsActive { get; set; }

        public virtual ICollection<BookLoan> BookLoans { get; set; }
    }

    public class BookLoan
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("Book")]
        public int BookId { get; set; }

        [ForeignKey("Reader")]
        public int ReaderId { get; set; }

        [ForeignKey("Admin")]
        public int AdminId { get; set; }

        public DateTime LoanDate { get; set; }

        public DateTime DueDate { get; set; }

        public DateTime? ReturnDate { get; set; }

        [MaxLength(50)]
        public string Status { get; set; }

        public decimal? FineAmount { get; set; }

        public string Notes { get; set; }
        public required virtual Book Book { get; set; }
        public virtual Reader Reader { get; set; }
        public virtual Admin Admin { get; set; }
    }
}
